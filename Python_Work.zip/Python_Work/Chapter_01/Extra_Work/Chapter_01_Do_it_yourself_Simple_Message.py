PeoplesNames = []

PeoplesNames.append('Kabelo')
PeoplesNames.append('Samkelo')
PeoplesNames.append('Bantu')
PeoplesNames.append('Thozamile')
PeoplesNames.append('Domsie')
PeoplesNames.append('Werner')
PeoplesNames.append('Arno')

print(PeoplesNames)