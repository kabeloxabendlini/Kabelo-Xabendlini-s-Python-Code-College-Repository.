# first_name = "kabelo"
# last_name = "xabendlini"
# full_name = f"{first_name} {last_name}"
# print(full_name.title())

##########################################################################

# name = "kabelo xabendlini"
# print(name.title())

# name = "kabelo xabendlini"
# print(name.upper())

# name = "kabelo xabendlini"
# print(name.lower())

##########################################################################

# my_message = "Hello World."
# print(my_message)

# my_message = "Hello Kabelo."
# print(my_message)

##########################################################################

# name = "Hello Kabelo."
# print(name.title())

# name = "Would you like to know more about Python today?"
# print(name.upper()) 

# first_name = "Kabelo"
# message = f"Hello {first_name}, would you like to learn about Python today?"

# print(message)

#######################################################################

# first_name = "kabelo"
# last_name = "xabendlini"
# full_name = f"{first_name} {last_name}"

# print(full_name.title())
# print(full_name.upper())
# print(full_name.lower())

#######################################################################

# famous_name = "franklin roosevelt"
# quote = '"once said:the only thing we have to fear is fear itself."'

# famous_quote = f"{famous_name} {quote}"

# print(famous_quote)

#########################################################################

# famous_person = "franklin roosevelt"
# message = '"once said:the only thing we have to fear is fear itself."'

# message = f"{famous_person.title()} {message.lower()}"

# print(message)

##########################################################################

# print("Languages:\n \t Python \n \t Node.js \n \t HMLX")

##########################################################################

famous_person = "\n \t  franklin roosevelt \t \n "

print(famous_person.rstrip())
print(famous_person.lstrip())
print(famous_person.strip())    
                    

###########################################################################

# nostarch_url = 'https://nostarch.com'
# print(nostarch_url.removesuffix('.com'))

###########################################################################

# print(3+5)
# print(17-9)
# print(4*2)
# print(64/8)

##########################################################################

# favourite_number = 7
# message = f"my favourite number is {favourite_number}."

# print(message)

###########################################################################