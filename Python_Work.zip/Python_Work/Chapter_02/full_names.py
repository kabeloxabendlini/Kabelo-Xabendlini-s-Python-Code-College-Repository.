first_name = "kabelo"
last_name = "xabendlini"
full_name = f"{first_name} {last_name}"
message = f"Hello, my full name is {full_name.title()}!"
print(message)

