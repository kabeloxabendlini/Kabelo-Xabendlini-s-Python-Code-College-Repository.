# friends = ['Werner', 'Samkelo', 'Tamiya', 'Thozie', 'Bantu', 'Thuso', 'Jason']

# print(friends[0].title())
# print(friends[1].title())
# print(friends[2].title())
# print(friends[3].title())
# print(friends[4].title())
# print(friends[5].title())
# print(friends[6].title())

##################################################################################

# friends = ['Werner', 'Samkelo', 'Tamiya', 'Thozie', 'Bantu', 'Thuso', 'Jason']
# message = f"My friend is {friends}."

# print(message)

##################################################################################

# transports = ['Motorcyce', 'Bus', 'Bike', 'Boat', 'Yacht', 'Car', 'SUV']
# print(transports)

##################################################################################

# friends = ['Mr.Jombile', 'Tamiya', 'Thozie', 'Samkelo', 'Bantu']
# print(friends)

###################################################################################

friends = ['Mr.Jombile', 'Tamiya', 'Thozie', 'Samkelo', 'Bantu']
print(friends)

could_not_make_it = (friends[4])
friends.remove(friends[4])
print(friends)
print(f"\nA {friends[2].title()} was busy so he could not make it.")

####################################################################################

