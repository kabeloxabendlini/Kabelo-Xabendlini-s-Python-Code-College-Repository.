CarBrandsAndModels = ['Audi 80 RS', 'B.M.W M5 M', 'Bentley Continental GT', 'Bugatti Chiron']
message = f"My first car was a modest {CarBrandsAndModels[1].title()}."

print(message)