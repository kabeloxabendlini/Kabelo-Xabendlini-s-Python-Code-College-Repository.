# List of animals with a common characteristic (they all make great pets)
animals = ["Dog", "Cat", "Rabbit"]

# Loop through the list and print a statement about each animal
for animal in animals:
    print(f"A {animal.lower()} would make a great pet.")

# Final statement outside the loop
print("\nAny of these animals would make a great pet!")