# Print numbers from 1 to 20 using a for loop

for number in range(1, 21):
    print(number)