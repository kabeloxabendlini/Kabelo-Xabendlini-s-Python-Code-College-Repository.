# Create a list of odd numbers from 1 to 20 using range() with a step of 2
odd_numbers = list(range(1, 21, 2))

# Use a for loop to print each number
for number in odd_numbers:
    print(number)