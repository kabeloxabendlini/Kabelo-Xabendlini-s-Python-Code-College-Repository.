# Create a list of numbers from 1 to 1,000,000
numbers = list(range(1, 1000001))

# Use a for loop to print the numbers
for number in numbers:
    print(number)