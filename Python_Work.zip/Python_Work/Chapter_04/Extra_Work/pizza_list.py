# List of favorite pizzas
favorite_pizzas = ["Pepperoni", "Margherita", "BBQ Chicken"]

# Loop through the list and print a sentence about each pizza
for pizza in favorite_pizzas:
    print(f"I like {pizza} pizza.")

# Final statement outside the loop
print("\nPepperoni is my go-to for movie nights.")
print("Margherita is perfect when I want something classic and light.")
print("BBQ Chicken is great when I’m in the mood for something bold.")
print("I really love pizza!")