# Create a list of numbers from 1 to 1,000,000
numbers = list(range(1, 1000001))

# Use min(), max(), and sum() functions
print("Minimum number:", min(numbers))
print("Maximum number:", max(numbers))
print("Sum of all numbers:", sum(numbers))