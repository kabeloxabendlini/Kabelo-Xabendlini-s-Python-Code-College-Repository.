# Create a list of multiples of 3 from 3 to 30
multiples_of_3 = list(range(3, 31, 3))

# Use a for loop to print each number
for number in multiples_of_3:
    print(number)