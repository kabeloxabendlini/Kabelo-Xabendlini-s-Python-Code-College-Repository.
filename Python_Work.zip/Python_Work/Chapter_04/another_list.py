# 

another_list = [5, 10, 15, 20, 25]

print (another_list [2:5]) 