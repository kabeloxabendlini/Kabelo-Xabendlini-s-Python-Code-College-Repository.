message = "Hello Python world!"
print(message)

# With indentation it returns an error.