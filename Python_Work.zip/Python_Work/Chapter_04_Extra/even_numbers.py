# Create a list of even numbers from 2 to 10
# The range starts at 2, ends before 11, and increases by 2 each time
even_numbers = list(range(2, 11, 2))

# Print the list of even numbers
print(even_numbers)
