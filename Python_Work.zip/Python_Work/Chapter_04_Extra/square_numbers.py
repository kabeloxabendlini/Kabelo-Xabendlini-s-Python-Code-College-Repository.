# Create an empty list to store the squares
squares = []

# Loop through numbers 1 to 10
for value in range(1, 11):
    square = value ** 2  # Calculate the square of the number
    squares.append(square)  # Add the square to the list

# Print the list of squares
print(squares)

# Create an empty list to store the squares of numbers
squares = []

# Loop through numbers 1 to 10
for value in range(1, 11):
    # Calculate the square and add it to the list
    squares.append(value ** 2)

# Print the final list of squares
print(squares)
