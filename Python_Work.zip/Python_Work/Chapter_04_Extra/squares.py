# Create a list of squares from 1 to 10 using list comprehension
squares = [value**2 for value in range(1, 11)]

# Print the list of squares
print(squares)
