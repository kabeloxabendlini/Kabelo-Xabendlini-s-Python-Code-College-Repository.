alien_color = 'red'  # This will not pass the test

if alien_color == 'green':
    print("You just earned 5 points!")