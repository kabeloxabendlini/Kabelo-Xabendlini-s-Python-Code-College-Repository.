alien_color = 'green'  # This will pass the test

if alien_color == 'green':
    print("You just earned 5 points!")
