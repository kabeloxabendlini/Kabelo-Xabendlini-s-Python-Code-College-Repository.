# Step 1: Create the list of favorite fruits
favorite_fruits = ['mango', 'banana', 'strawberry']

# Step 2: Write five independent if statements
if 'banana' in favorite_fruits:
    print("You really like bananas!")

if 'mango' in favorite_fruits:
    print("You really like mangoes!")

if 'strawberry' in favorite_fruits:
    print("You really like strawberries!")

if 'apple' in favorite_fruits:
    print("You really like apples!")

if 'orange' in favorite_fruits:
    print("You really like oranges!")