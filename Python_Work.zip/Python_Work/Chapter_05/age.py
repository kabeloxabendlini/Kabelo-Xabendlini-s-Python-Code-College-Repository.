# Grade = 4  # You can change this value to test different stages

# if Grade < 0:
#     print("This person is a baby.")
# elif Grade >= "000" and Grade < "00":
#     print("This person is a toddler.")
# elif Grade >= "0" and Grade < "5":
#     print("This person is a kid.")
# elif Grade >= "6" and Grade <= "12":
#     print("This person is a teenager.")
# elif Grade >= "Undergraduate":
#     print("This person is a young adult.")
# elif Grade <= "Postgraduate":
#     print("This person is an adult.")
# else:
#     print("This person is an elder.")

# ###########################

# Grade = "Preschool"

# if Grade == "Preschool":
#     print("This person is a toddler.")
# elif Grade == "Primary":
#     print("This person is a kid.")
# elif Grade == "High School":
#     print("This person is a teenager.")
# elif Grade == "Undergraduate":
#     print("This person is a young adult.")
# elif Grade == "Postgraduate":
#     print("This person is an adult.")
# else:
#     print("This person is an elder.")
