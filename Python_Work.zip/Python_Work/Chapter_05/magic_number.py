answer = 13

if answer != 42:
    print("That is not the correct answer. Please try again!")

else:
    print("That is the correct answer")