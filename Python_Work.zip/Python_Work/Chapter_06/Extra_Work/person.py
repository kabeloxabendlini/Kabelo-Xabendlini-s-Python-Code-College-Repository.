# Create a dictionary to store information about a person
person = {
    'first_name': 'Kabelo',
    'last_name': 'Xabendlini',
    'age': 25,
    'city': 'Johannesburg'
}

# Print each piece of information
print("First name:", person['first_name'])
print("Last name:", person['last_name'])
print("Age:", person['age'])
print("City:", person['city'])