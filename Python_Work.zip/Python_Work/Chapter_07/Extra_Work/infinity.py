# 7-7. Infinity

while True:
    print("This loop will run forever!")