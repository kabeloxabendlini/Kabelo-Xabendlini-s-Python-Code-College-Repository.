# 7-1. Rental Car

# Ask the user what kind of rental car they would like
car = input("What kind of rental car would you like? ")

# Print a message about the car
print(f"Let me see if I can find you a {car.title()}.")