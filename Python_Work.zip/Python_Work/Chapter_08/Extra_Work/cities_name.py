def city_country(city, country):
    return f"{city}, {country}"

# Call the function with 3 city-country pairs
print(city_country("Santiago", "Chile"))
print(city_country("Tokyo", "Japan"))
print(city_country("Cape Town", "South Africa"))