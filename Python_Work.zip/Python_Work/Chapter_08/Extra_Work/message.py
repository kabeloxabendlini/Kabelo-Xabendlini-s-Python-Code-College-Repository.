def display_message():
    print("I am learning about functions in Python and how to use them.")

# Call the function
display_message()