def show_messages(messages):
    for message in messages:
        print(message)

# List of short text messages
text_messages = [
    "Hey, how are you?",
    "Don't forget the meeting at 3 PM.",
    "Happy Birthday!",
    "See you later!"
]

# Call the function
show_messages(text_messages)