from imported_admin import Admin

admin_user = Admin("Sarah", "Williams")
admin_user.privileges.show_privileges()