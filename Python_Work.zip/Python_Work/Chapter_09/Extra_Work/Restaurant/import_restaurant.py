from restaurant import Restaurant

# Create an instance
my_restaurant = Restaurant("Tasty Bites", "Mexican")

# Call a method to test import
my_restaurant.describe_restaurant()