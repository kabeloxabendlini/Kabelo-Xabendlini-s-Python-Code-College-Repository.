# main.py
from main import Admin

admin_user = Admin("Sarah", "Williams")
admin_user.privileges.show_privileges()